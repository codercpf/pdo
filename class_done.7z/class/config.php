<?php 
define("DB_HOST", 'localhost');
define('DB_USER', 'root');
define('DB_PWD',  'root');
define('DB_NAME', 'imooc');
define('DB_PORT', '3306');
define('DB_TYPE', 'mysql');
define('DB_CHARSET', 'utf8');